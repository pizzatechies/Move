package com.move.move

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
